#!/usr/bin/env python3

import re
import base64
import struct
import subprocess

def analyze_suspicious_strings():
    """Analisis string-string mencurigakan yang ditemukan"""
    
    # String mencurigakan dari hasil sebelumnya
    suspicious = [
        "}!I9", "}wzL", "}HH)", "%){", "%{0", "`}kb", "@}Nb", 
        "oAba}H", "ba}H", "ba}(", "tN", "<}waUD", "{pdE", 
        "{8H)", "}DA9", "{Q}<", "?}Ht", "{<6w", "?}t#", "?}&Z",
        "t{HcC", "^B{ $I", "w};u", "!{>;b", "ZzY8<{j", 
        "<{O+", "s%{^%", "{[P`x", "dISoy}h", "MD}9"
    ]
    
    print("🔍 Analisis String Mencurigakan:")
    print("=" * 50)
    
    # Coba gabungkan string-string ini
    combined = ''.join(suspicious)
    print(f"Combined string: {combined}")
    
    # Cek apakah ada pola base64
    for s in suspicious:
        if len(s) >= 4:
            try:
                decoded = base64.b64decode(s + '==')  # Tambah padding
                if all(32 <= b <= 126 for b in decoded):  # Printable ASCII
                    print(f"  Possible base64 '{s}': {decoded}")
            except:
                pass
    
    # Cek apakah ada pola flag tersembunyi dalam urutan
    all_chars = ''.join(suspicious)
    
    # Cari pola CBC{...}
    flag_pattern = re.findall(r'CBC\{[^}]*\}', all_chars, re.IGNORECASE)
    if flag_pattern:
        print(f"🎉 POTENTIAL FLAG: {flag_pattern}")
    
    # Cari pola {}
    brace_pattern = re.findall(r'\{[^}]{10,}\}', all_chars)
    if brace_pattern:
        print(f"🎯 Potential flag content: {brace_pattern}")

def create_buffer_overflow_payload():
    """Buat payload buffer overflow yang lebih spesifik"""
    
    print("\n🎯 Creating targeted buffer overflow payloads...")
    
    # Payload untuk mencoba trigger hidden functionality
    payloads = []
    
    # Payload 1: Standard overflow dengan magic values
    magic_values = [0x41424344, 0x43424300, 0xDEADBEEF, 0xCAFEBABE]
    
    for magic in magic_values:
        payload = struct.pack('<I', 0x100000)  # 1MB size
        payload += struct.pack('B', 4)         # pointer_length_width
        
        # Tambah magic value di berbagai posisi
        payload += struct.pack('<I', magic)
        payload += b'A' * 100
        payload += struct.pack('<I', magic)
        payload += b'FLAG' * 25
        
        b64_payload = base64.b64encode(payload).decode()
        payloads.append((f"Magic {hex(magic)}", b64_payload))
    
    # Payload 2: Format string attack
    format_payload = struct.pack('<I', 0x1000)
    format_payload += struct.pack('B', 8)
    format_payload += b'%x' * 50  # Format string
    b64_format = base64.b64encode(format_payload).decode()
    payloads.append(("Format String", b64_format))
    
    # Payload 3: Return address overwrite simulation
    ret_payload = struct.pack('<I', 0x10000)
    ret_payload += struct.pack('B', 4)
    ret_payload += b'A' * 1000
    ret_payload += b'BBBB'  # Fake return address
    ret_payload += b'CCCC'  # Parameters
    b64_ret = base64.b64encode(ret_payload).decode()
    payloads.append(("Return Overwrite", b64_ret))
    
    return payloads

def test_specific_payloads():
    """Test payload-payload spesifik"""
    
    payloads = create_buffer_overflow_payload()
    
    for name, payload in payloads:
        print(f"\n🧪 Testing {name}:")
        print(f"   Payload: {payload[:50]}...")
        
        try:
            # Decode payload untuk file
            decoded = base64.b64decode(payload)
            
            with open('test_payload.lz', 'wb') as f:
                f.write(decoded)
            
            # Test dengan binary
            result = subprocess.run(['./lz1.exe', 'd', 'test_payload.lz', 'test_out.txt'], 
                                  capture_output=True, text=True, timeout=5)
            
            if result.stdout:
                print(f"   STDOUT: {result.stdout}")
                if 'cbc{' in result.stdout.lower() or 'flag' in result.stdout.lower():
                    print(f"   🎉 POTENTIAL FLAG IN STDOUT!")
            
            if result.stderr:
                print(f"   STDERR: {result.stderr}")
                if 'cbc{' in result.stderr.lower() or 'flag' in result.stderr.lower():
                    print(f"   🎉 POTENTIAL FLAG IN STDERR!")
            
            # Cek output file
            try:
                with open('test_out.txt', 'rb') as f:
                    output = f.read()
                    if output:
                        print(f"   OUTPUT: {output[:100]}")
                        if b'cbc{' in output.lower() or b'flag' in output.lower():
                            print(f"   🎉 POTENTIAL FLAG IN OUTPUT!")
            except:
                pass
                
        except subprocess.TimeoutExpired:
            print(f"   ⏰ TIMEOUT - might be successful!")
        except Exception as e:
            print(f"   ❌ Error: {e}")

if __name__ == "__main__":
    print("🎮 Advanced Flag Analysis for LZ1")
    print("=" * 50)
    
    analyze_suspicious_strings()
    test_specific_payloads()
    
    print("\n💡 NEXT STEPS:")
    print("1. Coba jalankan ELF binary asli di Linux environment")
    print("2. Gunakan debugger (GDB) untuk analisis runtime") 
    print("3. Cek apakah ada hidden functions yang dipanggil saat overflow")
    print("4. Analisis memory layout saat runtime")
    print("5. Coba reverse engineering dengan tools seperti Ghidra/IDA")
