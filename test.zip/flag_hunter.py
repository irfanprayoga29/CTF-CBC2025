#!/usr/bin/env python3

import struct
import base64
import subprocess
import tempfile
import os

def analyze_binary():
    """Analisis lebih detail pada binary lz1"""
    print("🔍 Analisis Binary lz1 untuk mencari flag...")
    
    # Cari semua string yang mungkin berisi flag
    try:
        result = subprocess.run(['strings', 'lz1'], capture_output=True, text=True)
        strings_output = result.stdout.split('\n')
        
        suspicious_strings = []
        for s in strings_output:
            if any(pattern in s.lower() for pattern in ['cbc', 'flag', 'ctf', '{', '}', 'win', 'success']):
                if len(s) > 3:  # Ignore short strings
                    suspicious_strings.append(s)
        
        if suspicious_strings:
            print("🎯 Suspicious strings found:")
            for s in suspicious_strings:
                print(f"  - {s}")
        else:
            print("❌ No obvious flag strings found")
            
    except:
        print("⚠️  'strings' command not available, using PowerShell method...")
        
def create_rop_payload():
    """Buat payload yang lebih sophisticated untuk ROP/shellcode execution"""
    print("\n🛠️  Membuat advanced payload...")
    
    # Berbagai ukuran untuk testing
    test_sizes = [
        0x1000,      # 4KB - small overflow
        0x10000,     # 64KB - medium overflow  
        0x100000,    # 1MB - large overflow
        0x1000000,   # 16MB - very large
    ]
    
    for i, size in enumerate(test_sizes):
        # Header standar
        payload = struct.pack('<I', size)  # uncompressed_size
        payload += struct.pack('B', 4)     # pointer_length_width
        
        # Coba berbagai pattern untuk mencari magic value
        patterns = [
            b'A' * 100,  # Standard pattern
            b'FLAG' * 25,  # Flag pattern
            b'CBC{' + b'A' * 95,  # CBC format
            b'\x41\x41\x41\x41' * 25,  # Hex pattern
            b'\x90' * 100,  # NOP sled pattern
        ]
        
        for j, pattern in enumerate(patterns):
            test_payload = payload + pattern[:min(len(pattern), 1000)]
            b64_payload = base64.b64encode(test_payload).decode()
            
            print(f"Payload {i+1}.{j+1}: Size {hex(size)}, Pattern {j+1}")
            print(f"  Base64: {b64_payload[:50]}...")
            
            # Test payload
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix='.lz') as f:
                    f.write(test_payload)
                    f.flush()
                    
                    # Test with lz1.exe
                    result = subprocess.run(['lz1.exe', 'd', f.name, 'output.tmp'], 
                                          capture_output=True, text=True, timeout=3)
                    
                    if result.stdout and ('flag' in result.stdout.lower() or 'cbc' in result.stdout.lower()):
                        print(f"  🎉 POTENTIAL FLAG FOUND IN STDOUT:")
                        print(f"     {result.stdout}")
                        
                    if result.stderr and ('flag' in result.stderr.lower() or 'cbc' in result.stderr.lower()):
                        print(f"  🎉 POTENTIAL FLAG FOUND IN STDERR:")
                        print(f"     {result.stderr}")
                    
                os.unlink(f.name)
                if os.path.exists('output.tmp'):
                    # Check output file
                    with open('output.tmp', 'rb') as out_f:
                        output_data = out_f.read()
                        if b'CBC{' in output_data or b'flag' in output_data.lower():
                            print(f"  🎉 POTENTIAL FLAG FOUND IN OUTPUT FILE:")
                            print(f"     {output_data}")
                    os.unlink('output.tmp')
                        
            except subprocess.TimeoutExpired:
                print(f"  ⏰ Timeout - possible hang")
            except Exception as e:
                print(f"  ❌ Error: {e}")

def check_environment_variables():
    """Cek apakah ada environment variables yang berisi flag"""
    print("\n🌍 Checking environment variables...")
    
    for key, value in os.environ.items():
        if any(pattern in key.lower() for pattern in ['flag', 'cbc', 'ctf']) or \
           any(pattern in value.lower() for pattern in ['flag', 'cbc{', 'ctf{']):
            print(f"  🎯 Found: {key} = {value}")

def search_file_system():
    """Cari file flag di sistem"""
    print("\n📁 Searching for flag files...")
    
    search_patterns = ['*flag*', '*CBC*', '*.flag', 'flag.txt']
    current_dir = os.getcwd()
    
    for pattern in search_patterns:
        try:
            result = subprocess.run(['dir', f'/s {pattern}'], 
                                  capture_output=True, text=True, shell=True, cwd=current_dir)
            if result.stdout and 'File Not Found' not in result.stdout:
                print(f"  🎯 Found files matching {pattern}:")
                print(f"     {result.stdout}")
        except:
            pass

if __name__ == "__main__":
    print("🎮 CBC CTF 2025 - LZ1 Flag Hunter")
    print("=" * 50)
    
    analyze_binary()
    check_environment_variables()
    search_file_system()
    create_rop_payload()
    
    print("\n" + "=" * 50)
    print("💡 TIPS untuk mendapatkan flag:")
    print("1. Flag mungkin di-print saat buffer overflow berhasil")
    print("2. Flag mungkin tersimpan di output file dekompresi")
    print("3. Flag mungkin muncul di stderr saat crash")
    print("4. Coba exploit dengan ELF binary asli (lz1) di Linux")
    print("5. Flag mungkin embedded di binary dan perlu ROP chain untuk akses")
