#!/usr/bin/env python3

import re
import string

def analyze_potential_flag():
    """Analisis string yang berpotensi sebagai flag"""
    
    # String yang ditemukan dari binary
    fragments = [
        "{HcC^B{ $Iw}",
        "{>;bZzY8<{j<{O+s%{^%{[P`xdISoy}"
    ]
    
    print("🎯 Analyzing Potential Flag Fragments:")
    print("=" * 50)
    
    for i, fragment in enumerate(fragments):
        print(f"\nFragment {i+1}: {fragment}")
        print(f"Length: {len(fragment)}")
        
        # Cek apakah ini format flag CBC
        if fragment.startswith('{') and fragment.endswith('}'):
            potential_flag = f"CBC{fragment}"
            print(f"Possible flag: {potential_flag}")
        
        # Analisis karakter
        printable = sum(1 for c in fragment if c in string.printable)
        print(f"Printable chars: {printable}/{len(fragment)}")
        
        # Coba decode sebagai berbagai encoding
        try:
            # ROT13
            rot13 = fragment.translate(str.maketrans(
                'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
                'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm'
            ))
            if rot13 != fragment:
                print(f"ROT13: {rot13}")
        except:
            pass

def extract_all_braces_content():
    """Ekstrak semua content dalam kurung kurawal dari strings hasil"""
    
    # Semua string yang ditemukan di binary
    all_strings = [
        "}!I9", "}wzL", "}HH)", "%){", "%{0", "`}kb", "@}Nb",
        "oAba}H", "ba}H", "ba}(", "tN", "<}waUD", "{pdE",
        "{8H)", "}DA9", "{Q}<", "?}Ht", "{<6w", "?}t#", "?}&Z",
        "t{HcC", "^B{ $I", "w};u", "!{>;b", "ZzY8<{j",
        "<{O+", "s%{^%", "{[P`x", "dISoy}h", "MD}9"
    ]
    
    print("\n🔍 Extracting ALL Brace Content:")
    print("=" * 50)
    
    # Gabungkan semua string
    combined = ''.join(all_strings)
    print(f"Combined: {combined}")
    
    # Cari semua pola dalam kurung kurawal
    brace_patterns = re.findall(r'\{[^{}]*\}', combined)
    print(f"Brace patterns: {brace_patterns}")
    
    # Cari pola yang dimulai dengan { dan diikuti huruf/angka
    flag_like = re.findall(r'\{[a-zA-Z0-9_$@!#%^&*()+=<>?/\[\]~`|\\-]+\}', combined)
    print(f"Flag-like patterns: {flag_like}")
    
    # Coba berbagai kombinasi
    possible_flags = []
    
    # Format CBC{...}
    for pattern in brace_patterns:
        possible_flags.append(f"CBC{pattern}")
    
    # Gabungan karakter dalam kurung
    brace_chars = []
    for s in all_strings:
        for char in s:
            if char not in '{}':
                brace_chars.append(char)
    
    brace_content = ''.join(brace_chars)
    print(f"All brace content: {brace_content}")
    
    # Cari pola flag dalam gabungan
    flag_match = re.search(r'CBC\{[^}]+\}|[A-Za-z0-9_]{20,}', brace_content)
    if flag_match:
        print(f"🎉 POTENTIAL COMPLETE FLAG: {flag_match.group()}")
    
    return possible_flags

def search_for_hidden_flag():
    """Cari flag tersembunyi dengan pattern matching"""
    
    print("\n🕵️ Searching for Hidden Flag Patterns:")
    print("=" * 50)
    
    # Pattern dari strings yang suspicious
    patterns = [
        "HcC^B{ $Iw",
        ">;bZzY8<{j<{O+s%{^%{[P`xdISoy",
        "!I9}wzL}HH)%){%{0`}kb@}NboAba}Hba}Hba}(tN<}waUD{pdE{8H)}DA9{Q}<?}Ht{<6w?}t#?}&Zt{HcC^B{ $Iw};u!{>;bZzY8<{j<{O+s%{^%{[P`xdISoy}hMD}9"
    ]
    
    for pattern in patterns:
        print(f"\nAnalyzing: {pattern}")
        
        # Coba ekstrak karakter alfanumerik saja
        alphanum = ''.join(c for c in pattern if c.isalnum() or c in '_$@')
        print(f"Alphanumeric: {alphanum}")
        
        # Coba berbagai transformasi
        reversed_pattern = pattern[::-1]
        print(f"Reversed: {reversed_pattern}")
        
        # Cek apakah ada substring yang terlihat seperti flag
        if len(alphanum) >= 10:
            print(f"Possible flag content: CBC{{{alphanum}}}")

def manual_flag_candidates():
    """Kandidat flag berdasarkan analisis manual"""
    
    candidates = [
        "CBC{HcC^B_$Iw}",
        "CBC{bZzY8O+s%^%[P`xdISoy}",
        "CBC{stack_overflow_lz77}",
        "CBC{alloca_heap_overflow}",
        "CBC{buffer_overflow_compression}",
        "CBC{lz77_decompression_vuln}"
    ]
    
    print("\n🎯 Manual Flag Candidates:")
    print("=" * 50)
    
    for i, candidate in enumerate(candidates, 1):
        print(f"{i}. {candidate}")
    
    print("\n💡 Try these candidates if automated search fails!")

if __name__ == "__main__":
    print("🎮 Flag Fragment Analysis - LZ1 CTF")
    print("=" * 60)
    
    analyze_potential_flag()
    possible_flags = extract_all_braces_content()
    search_for_hidden_flag()
    manual_flag_candidates()
    
    print("\n" + "=" * 60)
    print("🚀 CONCLUSION:")
    print("1. Potensi flag fragments ditemukan dalam binary")
    print("2. Mungkin perlu exploit yang tepat untuk memicu output flag")
    print("3. Flag kemungkinan tersembunyi dalam memory/runtime")
    print("4. Coba jalankan di Linux untuk hasil yang berbeda")
    
    if possible_flags:
        print(f"\n🎉 TOP FLAG CANDIDATES:")
        for flag in possible_flags[:5]:  # Top 5
            print(f"   - {flag}")
